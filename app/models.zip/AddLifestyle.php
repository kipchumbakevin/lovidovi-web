<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AddLifestyle extends Model
{
    protected $fillable = [
        'total','pickA','pickB'
    ];
}

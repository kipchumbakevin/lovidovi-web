<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AddPartner extends Model
{
    protected $fillable = [
        'total','pickA','pickB'
    ];
}

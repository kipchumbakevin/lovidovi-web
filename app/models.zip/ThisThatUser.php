<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ThisThatUser extends Model
{
    protected $fillable = [
        'phone','complete','would','lifestyle','food','celebrity','partner'
    ];
}
